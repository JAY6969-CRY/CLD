package com.example.prgm3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prgm3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
