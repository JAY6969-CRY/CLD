package com.example.prgm4.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.prgm4.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
}