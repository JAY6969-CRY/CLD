package com.example.prgm4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prgm4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
