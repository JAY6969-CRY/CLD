package com.example.prgm4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prgm4Application {

	public static void main(String[] args) {
		SpringApplication.run(Prgm4Application.class, args);
	}

}
