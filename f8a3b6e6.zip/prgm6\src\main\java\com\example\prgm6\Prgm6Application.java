package com.example.prgm6;

import org.hibernate.Session;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.prgm6.entity.Student;
import com.example.prgm6.util.HibernateUtil;

@SpringBootApplication
public class Prgm6Application {

    public static void main(String[] args) {

        // INSERT Student 1
        Student s1 = new Student();
        s1.setId(3);
        s1.setName("ML");
        s1.setAge(21);
        try (Session session = HibernateUtil.getSession()) {
            session.beginTransaction();
            session.persist(s1);
            session.getTransaction().commit();
            System.out.println("Inserted: " + s1.getName());
        }

        // INSERT Student 2
        Student s2 = new Student();
        s2.setId(22);
        s2.setName("Cloud");
        s2.setAge(26);
        try (Session session = HibernateUtil.getSession()) {
            session.beginTransaction();
            session.persist(s2);
            session.getTransaction().commit();
            System.out.println("Inserted: " + s2.getName());
        }

        // SELECT - Search by ID
        try (Session session = HibernateUtil.getSession()) {
            Student found = session.get(Student.class, 3);
            System.out.println("Found: "
                + found.getName()
                + ", Age: " + found.getAge());
        }

        // UPDATE - Change age of ML
        try (Session session = HibernateUtil.getSession()) {
            session.beginTransaction();
            Student found = session.get(Student.class, 3);
            found.setAge(21);
            session.merge(found);
            session.getTransaction().commit();
            System.out.println("Updated: " + found.getName()
                + ", New Age: " + found.getAge());
        }

        // SELECT ALL - Show final state
        try (Session session = HibernateUtil.getSession()) {
            var list = session.createQuery(
                "from Student", Student.class).list();
            System.out.println("\n--- Final Students in DB ---");
            for (Student s : list) {
                System.out.println("ID: " + s.getId()
                    + " | Name: " + s.getName()
                    + " | Age: " + s.getAge());
            }
        }
    }
}