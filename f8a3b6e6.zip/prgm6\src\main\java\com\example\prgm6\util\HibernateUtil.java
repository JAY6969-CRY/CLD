package com.example.prgm6.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.example.prgm6.entity.Student;

public class HibernateUtil {

    private static SessionFactory sessionFactory =
        new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Student.class)
            .buildSessionFactory();

    public static Session getSession() {
        return sessionFactory.openSession();
    }
}