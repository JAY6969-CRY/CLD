package com.example.prgm7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prgm7Application {

	public static void main(String[] args) {
		SpringApplication.run(Prgm7Application.class, args);
	}

}
