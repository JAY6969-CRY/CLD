package com.example.prgm1.service;
import org.springframework.stereotype.Service;

@Service
public class GreetService {
    public String greet() {
        return "Hello from Annotation Based DI!";
    }
}