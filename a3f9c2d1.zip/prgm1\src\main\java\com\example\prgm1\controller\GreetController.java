package com.example.prgm1.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.prgm1.service.GreetService;

@RestController
@RequestMapping("/api")
public class GreetController {

    @Autowired
    private GreetService service;

    @GetMapping("/greet")
    public String greet() {
        return service.greet();
    }
}
