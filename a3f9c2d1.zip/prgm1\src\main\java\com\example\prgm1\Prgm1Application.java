package com.example.prgm1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prgm1Application {

	public static void main(String[] args) {
		SpringApplication.run(Prgm1Application.class, args);
	}

}
