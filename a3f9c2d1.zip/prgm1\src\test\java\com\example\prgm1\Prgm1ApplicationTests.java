package com.example.prgm1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prgm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
