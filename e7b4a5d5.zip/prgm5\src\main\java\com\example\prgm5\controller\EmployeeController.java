package com.example.prgm5.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.prgm5.model.Employee;
import com.example.prgm5.repository.EmployeeRepository;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository repo;

    @GetMapping
    public List<Employee> getAll() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        return ResponseEntity.ok(repo.findById(id).get());
    }

    @PostMapping
    public ResponseEntity<?> create(
            @Valid @RequestBody Employee emp,
            BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(
                result.getAllErrors()
                      .stream()
                      .map(e -> e.getDefaultMessage())
                      .toList()
            );
        }
        return ResponseEntity.ok(repo.save(emp));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(
            @PathVariable Long id,
            @Valid @RequestBody Employee emp,
            BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(
                result.getAllErrors()
                      .stream()
                      .map(e -> e.getDefaultMessage())
                      .toList()
            );
        }
        Employee existing = repo.findById(id).get();
        existing.setName(emp.getName());
        existing.setAge(emp.getAge());
        existing.setEmail(emp.getEmail());
        return ResponseEntity.ok(repo.save(existing));
    }
}