package com.example.prgm2.service;
import org.springframework.stereotype.Service;

@Service
public class EngineService {
    public String start() {
        return "Engine started! Car is ready to drive.";
    }
}