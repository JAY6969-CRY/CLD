package com.example.prgm2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prgm2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
