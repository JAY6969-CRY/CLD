package com.example.prgm2.controller;
import org.springframework.web.bind.annotation.*;
import com.example.prgm2.service.EngineService;

@RestController
@RequestMapping("/api")
public class CarController {

    private EngineService engine;

    public CarController(EngineService engine) {
        this.engine = engine;
    }

    @GetMapping("/car")
    public String drive() {
        return engine.start();
    }
}
