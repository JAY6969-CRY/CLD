package com.example.prgm2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prgm2Application {

	public static void main(String[] args) {
		SpringApplication.run(Prgm2Application.class, args);
	}

}
